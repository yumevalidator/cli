# YumeValidator CLI

> CLI Tool to execute UI Validation AI Agent and display the report after the process has been completed

## To Run

```
pip3 install --editable .
yumevalidator version
```

Initialze react project to use the testing suite
```
yumevalidator init
```